/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Elang AbdUl Azis
 */
public class JenisKamar {
    String idjeniskamar,namajeniskamar,harga;

    public String getIdjeniskamar() {
        return idjeniskamar;
    }

    public void setIdjeniskamar(String idjeniskamar) {
        this.idjeniskamar = idjeniskamar;
    }

    public String getNamajeniskamar() {
        return namajeniskamar;
    }

    public void setNamajeniskamar(String namajeniskamar) {
        this.namajeniskamar = namajeniskamar;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }
    
}
