/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Pengembalian;
import View.FormPengembalian;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class PengembaliaDAO {
     public void insert(Connection con, Pengembalian pengembalian) throws SQLException{
        String sql = "insert into pengembalian values(?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, pengembalian.getNomorkamar());

        
        ps.executeUpdate();
    }
    

        
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from karyawan where id_karyawan=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Pengembalian getPengembalian(Connection con, String id) throws SQLException{
        String sql = "select * from pengembalian where id_customer=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Pengembalian pengembalian = null;
        if(rs.next()){
             pengembalian = new Pengembalian();
            pengembalian.setIdcus(rs.getString(1));
            pengembalian.setCheckout(rs.getString(2));
            pengembalian.setIdkamar(rs.getString(3));
            pengembalian.setNomorkamar(rs.getString(4));
            pengembalian.setJeniskamar(rs.getString(5));
        }
        return pengembalian;
    }
    
   
    public List<Pengembalian> getAllPengembalian(Connection con) throws SQLException{
        String sql = "select * from pengembalian";
        PreparedStatement ps = con.prepareStatement(sql);
        Pengembalian pengembalian = null;
        List<Pengembalian> listpengembalian= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            pengembalian = new Pengembalian();
            
       
            
            pengembalian.setNomorkamar(rs.getString(1));
          
            listpengembalian.add(pengembalian);
        }
        return listpengembalian;
    }
        public ResultSet getResultset(Connection con, String query) throws SQLException{
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }
          Connection con;
    
}

    
