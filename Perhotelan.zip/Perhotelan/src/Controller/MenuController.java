/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.User;
import View.FormMenu;

/**
 *
 * @author Elang AbdUl Azis
 */
public class MenuController {
     FormMenu view;
    
    public MenuController(FormMenu view){
        this.view = view;
    }
    
    public void nonAktif(){
        view.getCustomer().setVisible(false);
        view.getKamar().setVisible(false);
        view.getFasilitas().setVisible(false);
        view.getUser().setVisible(false);
        view.getPembayaran().setVisible(false);
        view.getJenisfasilitas().setVisible(false);
        view.getJeniskamar().setVisible(false);
        view.getUser().setVisible(false);
        view.getPengembalian().setVisible(false);
        
    }
    
    public  void Aktif(User user){
        if (user.getJabatan()==1) {            
        view.getCustomer().setVisible(true);
        view.getKamar().setVisible(true);
        view.getFasilitas().setVisible(true);
        view.getUser().setVisible(true);
        view.getPembayaran().setVisible(true);
        view.getJenisfasilitas().setVisible(true);
        view.getJeniskamar().setVisible(true);
        view.getUser().setVisible(true);
        view.getPengembalian().setVisible(true);
        }else if(user.getJabatan()==2){
            nonAktif();
            view.getMenuuser().setVisible(true);
            view.getMenutransaksi().setVisible(true);
            view.getMennujenis().setVisible(true);
           
        }
    }
}
