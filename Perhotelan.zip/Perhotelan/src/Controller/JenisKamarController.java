/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.JenisKamarDAO;
import Koneksi.Koneksi;
import Model.JenisKamar;
import View.DialogJenisKamar;
import View.FormJenisKamar;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
 public class JenisKamarController {
     FormJenisKamar view;
    JenisKamar jenisKamar;
    DialogJenisKamar dialogJenisKamar;
    
    public JenisKamarController(FormJenisKamar view) {
        this.view = view;
    }
        public JenisKamarController(DialogJenisKamar dialogJenisKamar){
        this.dialogJenisKamar = dialogJenisKamar;
        
        jenisKamar= new JenisKamar();
       
    }
          public void ViewDialogJenisKamar(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) dialogJenisKamar.getTabelDialogJenisKamar().getModel();
            tabelModel.setRowCount(0);
            JenisKamarDAO dao = new JenisKamarDAO(); //DAO
            Koneksi k = new Koneksi(); //koneksi
            String cari = dialogJenisKamar.getTxtFilterb().getText();
            Connection c = k.getKoneksi();
            String sql = "SELECT Jenis_kamar.*,kamar.no_kamar FROM jenis_kamar,kamar WHERE jenis_kamar.id_jenis=kamar.id_jenis and kamar.status=0";
            ResultSet rs = dao.getResultset(c, sql);
            while (rs.next()) {
                Object data[] = {
                    rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)
                };
                tabelModel.addRow(data);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }

  
    public void insertJenisKamar(){
        jenisKamar = new JenisKamar();
        jenisKamar.setIdjeniskamar(view.getTxtidjeniskamar().getText());
        jenisKamar.setNamajeniskamar(view.getTxtnamajenis().getText());
        jenisKamar.setHarga(view.getTxtharga().getText());
        JenisKamarDAO dao = new JenisKamarDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, jenisKamar);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void update(){
             jenisKamar = new JenisKamar();
        jenisKamar.setIdjeniskamar(view.getTxtidjeniskamar().getText());
        jenisKamar.setNamajeniskamar(view.getTxtnamajenis().getText());
        jenisKamar.setHarga(view.getTxtharga().getText());
        JenisKamarDAO dao = new JenisKamarDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, jenisKamar);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtidjeniskamar().getText();
            JenisKamarDAO dao = new JenisKamarDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cariData(){
        String idCari = view.getTxtidjeniskamar().getText();
        if(idCari.length()>0){
            try {
                JenisKamarDAO dao = new JenisKamarDAO();
                Koneksi k = new Koneksi();
                Connection c = k.getKoneksi();
                jenisKamar = dao.getJenisKamar(c, idCari);
                if(jenisKamar!=null){
                    view.getTxtidjeniskamar().setText(jenisKamar.getIdjeniskamar());
                    view.getTxtnamajenis().setText(jenisKamar.getNamajeniskamar());
                    view.getTxtharga().setText(jenisKamar.getHarga());
                } else{
                    JOptionPane.showMessageDialog(view, "Data Tidak Ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(view, "Input ID Cari");
        }
    }
    
    public void bersihFormJenis(){
        view.getTxtidjeniskamar().setText("");
        view.getTxtnamajenis().setText("");   
        view.getTxtharga().setText("");
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTablejeniskamar().getModel();
            tabelModel.setRowCount(0);
            JenisKamarDAO dao = new JenisKamarDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<JenisKamar> listJenisKamar = dao.getAllJenisKamar(c);
            for(JenisKamar j: listJenisKamar){
                Object data[]={
                  j.getIdjeniskamar(),j.getNamajeniskamar(),j.getHarga()
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
