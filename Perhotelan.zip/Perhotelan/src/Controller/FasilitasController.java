/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.FasilitasDAO;
import DAO.JenisFasilitasDAO;
import Koneksi.Koneksi;
import Model.Fasilitas;
import Model.JenisFasilitas;
import View.DialogFasilitas;
import View.FormFasilitas;
import View.FormJenisFasilitas;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LABSIKOMP22
 */
public class FasilitasController {
    FormFasilitas view;
     Fasilitas fasilitas;
     DialogFasilitas dialogFasilitas;
    
    public FasilitasController(FormFasilitas view) {
        this.view = view;
    }
    public FasilitasController (DialogFasilitas dialogFasilitas){
        this.dialogFasilitas=dialogFasilitas;
       fasilitas= new Fasilitas();
    }
    public void ViewDialogFasilitas(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) dialogFasilitas.getTabelDialogFasilitas().getModel();
            tabelModel.setRowCount(0);
            FasilitasDAO dao = new FasilitasDAO(); //DAO
            Koneksi k = new Koneksi(); //koneksi
            String cari = dialogFasilitas.getTxtFilterb().getText();
            Connection c = k.getKoneksi();
            String sql = "SELECT * FROM jenis_fasilitas where id_fasilitas like '" + cari + "%' or nama_fasilitas like '" + cari + "%'";
            ResultSet rs = dao.getResultset(c, sql);
            while (rs.next()) {
                Object data[] = {
                    rs.getString(1),rs.getString(2),rs.getString(3)
                };
                tabelModel.addRow(data);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
  
    
    
    
    
    
    
    public void insertfasilitas(){
        fasilitas = new Fasilitas();
        fasilitas.setNofasilitas(view.getTxtnofasi().getText());
        String t_idjenis[]=view.getCmbjenis().getSelectedItem().toString().split("-");
        fasilitas.setIdjenis(t_idjenis[0]);
        
        FasilitasDAO dao = new FasilitasDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, fasilitas);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void update(){
        fasilitas = new Fasilitas();
        String t_idjenis[]=view.getCmbjenis().getSelectedItem().toString().split("-");
        fasilitas.setIdjenis(t_idjenis[0]);
        fasilitas.setNofasilitas(view.getTxtnofasi().getText());
        
        
        FasilitasDAO dao = new FasilitasDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, fasilitas);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }  
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtnofasi().getText().toString();
            FasilitasDAO dao = new FasilitasDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(FasilitasController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cariData(){
        String idCari = view.getTxtnofasi().getText();
        if (idCari.length()>0){
            try {
                FasilitasDAO dao = new FasilitasDAO();
                Koneksi k = new Koneksi();
                Connection conn = k.getKoneksi();
                fasilitas = dao.getFasilitas(conn, idCari);
                if(fasilitas !=null){
                    
                    
                    
                    JenisFasilitasDAO pdao = new JenisFasilitasDAO();
                    JenisFasilitas jenisfasilitas = pdao.getFasilitas(conn, fasilitas.getIdjenis());
                    view.getCmbjenis().setSelectedItem(jenisfasilitas.getIdfasi()+"-"+jenisfasilitas.getNamafasi());
                    view.getTxtnofasi().setText(fasilitas.getNofasilitas());
                    JOptionPane.showMessageDialog(view, "Data ditemukan !");
                }
                else{
                    JOptionPane.showMessageDialog(view, "Data tidak ada");
                }
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(FasilitasController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else{
            
                JOptionPane.showMessageDialog(view, "Masukkan ID");
            }
   }
    
    public void bersihFormJenis(){
        view.getCmbjenis().setSelectedItem("");
        view.getTxtnofasi().setText("");   
        
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTableFasi().getModel();
            tabelModel.setRowCount(0);
            FasilitasDAO dao = new FasilitasDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Fasilitas> listfasilitas = dao.getAllfasilitas(c);
            for(Fasilitas j: listfasilitas){
                Object data[]={
                  j.getIdjenis(),j.getNofasilitas()
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(FasilitasController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void isiComboFasilitas(){
        try {
            JenisFasilitasDAO dao = new JenisFasilitasDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<JenisFasilitas> listJenisfasilitas = dao.getAllJenisfasiilitas(c);
            view.getCmbjenis().removeAllItems();
            for (JenisFasilitas jenisfasilitas : listJenisfasilitas){
                view.getCmbjenis().addItem(jenisfasilitas.getIdfasi()+"-"+jenisfasilitas.getNamafasi());
            }
        } catch (SQLException ex) {
            Logger.getLogger(FasilitasController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FasilitasController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
