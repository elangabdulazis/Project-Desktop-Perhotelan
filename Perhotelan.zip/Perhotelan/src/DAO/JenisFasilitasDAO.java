/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.JenisFasilitas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class JenisFasilitasDAO {
     public void insert(Connection con, JenisFasilitas jenisFasilitas) throws SQLException{
        String sql = "insert into jenis_fasilitas values(?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, jenisFasilitas.getIdfasi());
        ps.setString(2, jenisFasilitas.getNamafasi());
        ps.setString(3, jenisFasilitas.getHargafasi());
        
        ps.executeUpdate();
    }
    
    public void update(Connection con,  JenisFasilitas jenisFasilitas) throws SQLException{
        String sql = "update jenis_fasilitas set  nama_fasilitas=?, harga_fasilitas=? where id_fasilitas=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, jenisFasilitas.getNamafasi());
        ps.setString(2, jenisFasilitas.getHargafasi());
        ps.setString(3, jenisFasilitas.getIdfasi());
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from jenis_fasilitas where id_fasilitas=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public JenisFasilitas getFasilitas(Connection con, String id) throws SQLException{
        String sql = "select * from jenis_fasilitas where id_fasilitas=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        JenisFasilitas jenisFasilitas = null;
        if(rs.next()){
            jenisFasilitas = new JenisFasilitas();
            jenisFasilitas.setIdfasi(rs.getString(1));
            jenisFasilitas.setNamafasi(rs.getString(2));
            jenisFasilitas.setHargafasi(rs.getString(3));

        }
        return jenisFasilitas;
    }
    
   
    public List<JenisFasilitas> getAllJenisfasiilitas(Connection con) throws SQLException{
        String sql = "select * from jenis_fasilitas";
        PreparedStatement ps = con.prepareStatement(sql);
        JenisFasilitas jenisFasilitas = null;
        List<JenisFasilitas> listJenisFasilitas= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            jenisFasilitas = new JenisFasilitas();
            jenisFasilitas.setIdfasi(rs.getString(1));
            jenisFasilitas.setNamafasi(rs.getString(2));
             jenisFasilitas.setHargafasi(rs.getString(3));
            listJenisFasilitas.add(jenisFasilitas);
        }
        return listJenisFasilitas;
    }
}
