/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Elang AbdUl Azis
 */
public class Customer {
    String idcus,namacus,nopcus;

    public String getIdcus() {
        return idcus;
    }

    public void setIdcus(String idcus) {
        this.idcus = idcus;
    }

    public String getNamacus() {
        return namacus;
    }

    public void setNamacus(String namacus) {
        this.namacus = namacus;
    }

    public String getNopcus() {
        return nopcus;
    }

    public void setNopcus(String nopcus) {
        this.nopcus = nopcus;
    }
    
    
}
