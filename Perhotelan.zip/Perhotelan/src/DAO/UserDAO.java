/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Elang AbdUl Azis
 */
public class UserDAO {
     public void insert(Connection con, User user) throws SQLException{
        String sql = "insert into user values(?,(?),?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, user.getUsername());
        ps.setString(2, user.getPassword());
        ps.setInt(3, user.getJabatan());
        ps.executeUpdate();
    }
    
    public User getUser(Connection con, String username, String password) throws SQLException{
        String sql = "select * from user where username=? and password=(?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, username);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        User user = null;
        if(rs.next()){
            user = new User();
            user.setUsername(rs.getString(1));
            user.setPassword(rs.getString(2));
            user.setJabatan(rs.getInt(3));
        }
        return user;
}
}
