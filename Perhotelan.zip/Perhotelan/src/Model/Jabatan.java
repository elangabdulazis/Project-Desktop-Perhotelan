/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Elang AbdUl Azis
 */
public class Jabatan {
    String namajabatam,idjabatan;

    public String getNamajabatam() {
        return namajabatam;
    }

    public void setNamajabatam(String namajabatam) {
        this.namajabatam = namajabatam;
    }

    public String getIdjabatan() {
        return idjabatan;
    }

    public void setIdjabatan(String idjabatan) {
        this.idjabatan = idjabatan;
    }
    
    
}
