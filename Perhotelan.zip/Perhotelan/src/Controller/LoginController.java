/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.UserDAO;
import Koneksi.Koneksi;
import Model.User;
import View.FormLogin;
import View.FormMenu;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 *
 * @author SISTEM_INFORMASI
 */
public class LoginController {
    FormLogin view;
    UserDAO userDAO;
    Connection con;
    User user;
    Koneksi k;
    MenuController menuController;
    FormMenu menu;
    
    public LoginController(FormLogin view){
        this.view=view;
        userDAO = new UserDAO();
        k = new Koneksi();
        user = new User();
        try {
            con=k.getKoneksi();
        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public void login(){
        
            String username = view.getTxtuser().getText();
            String password = view.getTxtpaswword().getText();
            try {
            User user = userDAO.getUser(con, username, password);
            if(user != null){
                view.getFormMenu().getMenuController().Aktif(user);
                view.dispose();
            }
            else{
                JOptionPane.showMessageDialog(view, "Invalid User");
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
