/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Elang AbdUl Azis
 */
public class Kamar {
    String Idjenis,Nokamar;
    int status,status1;

    public int getStatus1() {
        return status1;
    }

    public void setStatus1(int status1) {
        this.status1 = status1;
    }

    
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getIdjenis() {
        return Idjenis;
    }

    public void setIdjenis(String Idjenis) {
        this.Idjenis = Idjenis;
    }

    public String getNokamar() {
        return Nokamar;
    }

    public void setNokamar(String Nokamar) {
        this.Nokamar = Nokamar;
    }
    
    
}
