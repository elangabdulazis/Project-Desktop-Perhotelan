/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.JenisFasilitasDAO;
import Koneksi.Koneksi;
import Model.JenisFasilitas;
import View.FormJenisFasilitas;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
public class JenisFasilitasController {
    FormJenisFasilitas view;
    JenisFasilitas jenisFasilitas;
    
    public JenisFasilitasController(FormJenisFasilitas view) {
        this.view = view;
        
       jenisFasilitas= new JenisFasilitas();
    }

  
    public void insertJenisFasilitas(){
        jenisFasilitas = new JenisFasilitas();
        jenisFasilitas.setIdfasi(view.getTxtid().getText());
        jenisFasilitas.setNamafasi(view.getTxtnama().getText());
        jenisFasilitas.setHargafasi(view.getTxtharga().getText());
        JenisFasilitasDAO dao = new JenisFasilitasDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, jenisFasilitas);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void update(){
             jenisFasilitas = new JenisFasilitas();
        jenisFasilitas.setIdfasi(view.getTxtid().getText());
        jenisFasilitas.setNamafasi(view.getTxtnama().getText());
        jenisFasilitas.setHargafasi(view.getTxtharga().getText());
        JenisFasilitasDAO dao = new JenisFasilitasDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, jenisFasilitas);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtid().getText();
            JenisFasilitasDAO dao = new JenisFasilitasDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cariData(){
        String idCari = view.getTxtid().getText();
        if(idCari.length()>0){
            try {
                JenisFasilitasDAO dao = new JenisFasilitasDAO();
                Koneksi k = new Koneksi();
                Connection c = k.getKoneksi();
                jenisFasilitas = dao.getFasilitas(c, idCari);
                if(jenisFasilitas!=null){
                    view.getTxtid().setText(jenisFasilitas.getIdfasi());
                    view.getTxtnama().setText(jenisFasilitas.getNamafasi());
                    view.getTxtharga().setText(jenisFasilitas.getHargafasi());
                } else{
                    JOptionPane.showMessageDialog(view, "Data Tidak Ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(view, "Input ID Cari");
        }
    }
    
    public void bersihFormJenis(){
        view.getTxtid().setText("");
        view.getTxtnama().setText("");   
        view.getTxtharga().setText("");
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTablejenisfasi().getModel();
            tabelModel.setRowCount(0);
            JenisFasilitasDAO dao = new JenisFasilitasDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<JenisFasilitas> listJenisFasilitas = dao.getAllJenisfasiilitas(c);
            for(JenisFasilitas j: listJenisFasilitas){
                Object data[]={
                  j.getIdfasi(),j.getNamafasi(),j.getHargafasi()
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
