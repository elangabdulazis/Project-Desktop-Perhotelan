/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.CustomerDAO;
import DAO.KamarDAO;
import DAO.PengembaliaDAO;
import DAO.TransaksiDAO;
import Koneksi.Koneksi;
import Model.Customer;
import Model.Kamar;
import Model.Pengembalian;
import Model.Transaksi;
import View.DialogFasilitas;

import View.FormPengembalian;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
public class PengembalianController {
    
    
     FormPengembalian view;
    Pengembalian pengembalian;
    PengembaliaDAO dao;
    
    KamarDAO kamarDAO;
    Customer customer;
    CustomerDAO customerDAO;
    Connection con;
    Kamar kamar;
    PengembaliaDAO pengembaliaDAO;
        Koneksi koneksi;
     SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    
    public PengembalianController(FormPengembalian view) {
       try {
            this.view = view;
            pengembalian = new Pengembalian();
            pengembaliaDAO = new PengembaliaDAO();
            kamarDAO = new KamarDAO();
             Koneksi k = new Koneksi();
            con = k.getKoneksi();
        } catch (SQLException ex) {
            Logger.getLogger(PengembalianController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PengembalianController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 


    public void Viewdialogtransaksi(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTablepengembalian().getModel();
            tabelModel.setRowCount(0);
            PengembaliaDAO dao = new PengembaliaDAO(); //DAO
            Koneksi k = new Koneksi(); //koneksi
            String cari = view.getTxtidnomorkamar().getText();
            Connection c = k.getKoneksi();
            String sql = "select id_customer,check_out,no_kamar from transaksi";
            ResultSet rs = dao.getResultset(c, sql);
            while (rs.next()) {
                Object data[] = {
                    rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)
                };
                tabelModel.addRow(data);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
    

       public void insertpengembalian(){
               pengembalian = new Pengembalian();
            
               pengembalian.setNomorkamar(view.getTxtidnomorkamar().getText());
               PengembaliaDAO dao = new PengembaliaDAO(); //DAO
               Koneksi k = new Koneksi(); //koneksi
               
                try {
            Connection c = k.getKoneksi();
            dao.insert(c, pengembalian);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
           
        }
       public void bersihForm(){
                     
                   
                   
                    view.getTxtidnomorkamar().setText("");
                    
                     
                    
    }
       public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTablepengembalian().getModel();
            tabelModel.setRowCount(0);
            PengembaliaDAO dao = new PengembaliaDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Pengembalian> listPengembalians = dao.getAllPengembalian(c);
            for(Pengembalian j: listPengembalians){
                Object data[]={
               j.getNomorkamar()
                    
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }
     

   


