/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Elang AbdUl Azis
 */
public class JenisFasilitas {
    String idfasi,namafasi;
    String hargafasi;

    public String getHargafasi() {
        return hargafasi;
    }

    public void setHargafasi(String hargafasi) {
        this.hargafasi = hargafasi;
    }

    public String getIdfasi() {
        return idfasi;
    }

    public void setIdfasi(String idfasi) {
        this.idfasi = idfasi;
    }

    public String getNamafasi() {
        return namafasi;
    }

    public void setNamafasi(String namafasi) {
        this.namafasi = namafasi;
    }

    
    
    
}
