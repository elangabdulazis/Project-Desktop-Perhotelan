/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Karyawan;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class KaryawanDAO {
    public void insert(Connection con, Karyawan karyawan) throws SQLException{
        String sql = "insert into karyawan values(?,?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, karyawan.getIdkaryawan());
        ps.setString(2, karyawan.getNama());
        ps.setString(3, karyawan.getAlamat());
        ps.setString(4, karyawan.getNotelp());
        ps.setString(5, karyawan.getIdjenis());
        
        ps.executeUpdate();
    }
    
    public void update(Connection con,  Karyawan karyawan) throws SQLException{
        String sql = "update karyawan set alamat_karyawan=? ,nama_karyawan=?,no_telp_karyawan=?,id_jenis=? where id_karyawan=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, karyawan.getAlamat());
        ps.setString(2,karyawan.getNama());
        ps.setString(3, karyawan.getNotelp());
        ps.setString(4, karyawan.getIdjenis());
        ps.setString(5, karyawan.getIdkaryawan());
        
        
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from karyawan where id_karyawan=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Karyawan getKaryawan(Connection con, String id) throws SQLException{
        String sql = "select * from karyawan where id_karyawan=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Karyawan karyawan = null;
        if(rs.next()){
            karyawan = new Karyawan();
            karyawan.setIdkaryawan(rs.getString(1));
            karyawan.setNama(rs.getString(2));
            karyawan.setAlamat(rs.getString(3));
            karyawan.setNotelp(rs.getString(4));
            karyawan.setIdjenis(rs.getString(5));
        }
        return karyawan;
    }
    
   
    public List<Karyawan> getAllKaryawan(Connection con) throws SQLException{
        String sql = "select * from karyawan";
        PreparedStatement ps = con.prepareStatement(sql);
        Karyawan karyawan = null;
        List<Karyawan> listKaryawan= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            karyawan = new Karyawan();
            karyawan.setIdkaryawan(rs.getString(1));
            karyawan.setNama(rs.getString(2));
            karyawan.setAlamat(rs.getString(3));
            karyawan.setNotelp(rs.getString(4));
            karyawan.setIdjenis(rs.getString(5));
            listKaryawan.add(karyawan);
        }
        return listKaryawan;
    }
        public ResultSet getResultset(Connection con, String query) throws SQLException{
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }

}
