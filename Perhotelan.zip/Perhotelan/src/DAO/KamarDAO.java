/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Kamar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class KamarDAO {
    public void insert(Connection con, Kamar kamar) throws SQLException{
        String sql = "insert into kamar values(?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, kamar.getIdjenis());
        ps.setString(2, kamar.getNokamar());
        ps.setInt(3, kamar.getStatus());
        ps.executeUpdate();
    }
    
    public void update(Connection con,  Kamar kamar) throws SQLException{
        String sql = "update kamar set id_jenis=?,status=? where no_kamar=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, kamar.getIdjenis());
        ps.setString(3, kamar.getNokamar());
        ps.setInt(2, kamar.getStatus());

        ps.executeUpdate();
    }

    public void updateStatus(Connection con, int status,String idjenis) throws SQLException{
        String sql="update kamar set status=? where no_kamar=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, status);
        ps.setString(2, idjenis);
        ps.executeUpdate();
    }
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from kamar where no_kamar=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Kamar getKamar(Connection con, String id) throws SQLException{
        String sql = "select * from kamar where no_kamar=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Kamar kamar = null;
        if(rs.next()){
            kamar = new Kamar();
            kamar.setIdjenis(rs.getString(1));
            kamar.setNokamar(rs.getString(2));
            kamar.setStatus(rs.getInt(3));

        }
        return kamar;
    }
    
    public Kamar getStatus(Connection con) throws SQLException{
        String sql = "select * from kamar";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        Kamar kamar = null;
        if(rs.next()){
            kamar = new Kamar();
            kamar.setIdjenis(rs.getString(1));
            kamar.setNokamar(rs.getString(2));
            kamar.setStatus(rs.getInt(3));

        }
        return kamar;
    }
    
   
    public List<Kamar> getAllkamar(Connection con) throws SQLException{
        String sql = "select * from kamar";
        PreparedStatement ps = con.prepareStatement(sql);
        Kamar kamar = null;
        List<Kamar> listKamar= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            kamar = new Kamar();
            kamar.setIdjenis(rs.getString(1));
            kamar.setNokamar(rs.getString(2));
            kamar.setStatus(rs.getInt(3));
            listKamar.add(kamar);
        }
        return listKamar;
    }
     public ResultSet getResultset(Connection con, String query) throws SQLException{
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }
}
