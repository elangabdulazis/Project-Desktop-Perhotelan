/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.CustomerDAO;
import Koneksi.Koneksi;
import Model.Customer;
import View.DialogCustomer;
import View.Formcustomer;
import java.awt.Dialog;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
public class CustomerController {
    Formcustomer view;
    Customer customer;
    DialogCustomer dialogCustomer;
    
    public CustomerController(Formcustomer view) {
        this.view = view;
    }
    public  CustomerController(DialogCustomer dialogCustomer){
        this.dialogCustomer=dialogCustomer;
        
        
       customer= new Customer();
    }

    public void ViewDialogCustomer(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) dialogCustomer.getTabledialogcustomer().getModel();
            tabelModel.setRowCount(0);
            CustomerDAO dao = new CustomerDAO(); //DAO
            Koneksi k = new Koneksi(); //koneksi
            String cari = dialogCustomer.getTxtFilterb().getText();
            Connection c = k.getKoneksi();
            String sql = "select id_customer,nama_customer from customer where id_customer like '" + cari + "%' or nama_customer like '" + cari + "%'";
            ResultSet rs = dao.getResultset(c, sql);
            while (rs.next()) {
                Object data[] = {
                    rs.getString(1),rs.getString(2)
                };
                tabelModel.addRow(data);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
    
    
    
    
    
    public void insertCustomer(){
        customer = new Customer();
        customer.setIdcus(view.getTxtidcus().getText());
        customer.setNamacus(view.getTxtnamacus().getText());
        customer.setNopcus(view.getTxtnotelpcus().getText());
        CustomerDAO dao = new CustomerDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, customer);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void update(){
        customer = new Customer();
        customer.setIdcus(view.getTxtidcus().getText());
        customer.setNamacus(view.getTxtnamacus().getText());
        customer.setNopcus(view.getTxtnotelpcus().getText());
        CustomerDAO dao = new CustomerDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, customer);
            JOptionPane.showMessageDialog(view, "Update Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtidcus().getText();
            CustomerDAO dao = new CustomerDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cariData(){
        String idCari = view.getTxtidcus().getText();
        if(idCari.length()>0){
            try {
                CustomerDAO dao = new CustomerDAO();
                Koneksi k = new Koneksi();
                Connection c = k.getKoneksi();
                customer = dao.getCustomer(c, idCari);
                if(customer!=null){
                    view.getTxtnamacus().setText(customer.getNamacus());
                    view.getTxtnotelpcus().setText(customer.getNopcus());
                } else{
                    JOptionPane.showMessageDialog(view, "Data Tidak Ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(view, "Input ID Cari");
        }
    }
    
    public void bersihFormJenis(){
        view.getTxtidcus().setText("");
        view.getTxtnamacus().setText("");   
        view.getTxtnotelpcus().setText("");
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTampilTable().getModel();
            tabelModel.setRowCount(0);
            CustomerDAO dao = new CustomerDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Customer> listCustomer = dao.getAllCustomer(c);
            for(Customer j: listCustomer){
                Object data[]={
                  j.getIdcus(),j.getNamacus(),j.getNopcus()
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
