/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.JenisKamar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class JenisKamarDAO {
    public void insert(Connection con, JenisKamar jenisKamar) throws SQLException{
        String sql = "insert into jenis_kamar values(?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, jenisKamar.getIdjeniskamar());
        ps.setString(2, jenisKamar.getNamajeniskamar());
        ps.setString(3, jenisKamar.getHarga());
        
        ps.executeUpdate();
    }
    
    public void update(Connection con,  JenisKamar jenisKamar) throws SQLException{
        String sql = "update jenis_kamar set  nama_jenis_kamar=?, harga_jenis_kamar=? where id_jenis=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, jenisKamar.getNamajeniskamar());
        ps.setString(2, jenisKamar.getHarga());
        ps.setString(3, jenisKamar.getIdjeniskamar()); 
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from jenis_kamar where id_jenis=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public JenisKamar getJenisKamar(Connection con, String id) throws SQLException{
        String sql = "select * from jenis_kamar where id_jenis=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        JenisKamar jenisKamar = null;
        if(rs.next()){
            jenisKamar = new JenisKamar();
            jenisKamar.setIdjeniskamar(rs.getString(1));
            jenisKamar.setNamajeniskamar(rs.getString(2));
            jenisKamar.setHarga(rs.getString(3));

        }
        return jenisKamar;
    }
    
   
    public List<JenisKamar> getAllJenisKamar(Connection con) throws SQLException{
        String sql = "select * from jenis_kamar";
        PreparedStatement ps = con.prepareStatement(sql);
        JenisKamar jenisKamar = null;
        List<JenisKamar> listJenisKamar= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            jenisKamar = new JenisKamar();
            jenisKamar.setIdjeniskamar(rs.getString(1));
            jenisKamar.setNamajeniskamar(rs.getString(2));
            jenisKamar.setHarga(rs.getString(3));
            listJenisKamar.add(jenisKamar);
        }
        return listJenisKamar;
    }

     public ResultSet getResultset(Connection con, String query) throws SQLException{
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }
    
}
