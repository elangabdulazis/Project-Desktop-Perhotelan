/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.JenisKamarDAO;
import DAO.KamarDAO;
import DAO.TransaksiDAO;
import Koneksi.Koneksi;
import Model.JenisKamar;
import Model.Kamar;
import View.DialogJenisKamar;
import View.DialogTransaksi;
import View.FormKamar;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
public class KamarController {
     FormKamar view;
     Kamar kamar;
     DialogJenisKamar dialogJenisKamar;
     DialogTransaksi dialogTransaksi;
    
    public KamarController(FormKamar view) {
        this.view = view;
    }
     public KamarController(DialogJenisKamar dialogJenisKamar){
        this.dialogJenisKamar = dialogJenisKamar;
       kamar= new Kamar();
    } 
         public  KamarController(DialogTransaksi dialogTransaksi){
        this.dialogTransaksi=dialogTransaksi;
    }
   public void Viewdialogtransaksi(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) dialogTransaksi.getTabledialogtransaksi().getModel();
            tabelModel.setRowCount(0);
            TransaksiDAO dao = new TransaksiDAO(); //DAO
            Koneksi k = new Koneksi(); //koneksi
            String cari = dialogTransaksi.getTxtidkamar().getText();
            Connection c = k.getKoneksi();
            String sql = "select no_kamar from transaksi";
            ResultSet rs = dao.getResultset(c, sql);
            while (rs.next()) {
                Object data[] = {
                    rs.getString(1)
                };
                tabelModel.addRow(data);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
  
    public void insertkamar(){
        kamar = new Kamar();
        
        kamar.setNokamar(view.getTxtnokamar().getText());
        String t_idjenis[]=view.getCmbjenis().getSelectedItem().toString().split("-");
        kamar.setIdjenis(t_idjenis[0]);
        kamar.setStatus(view.getCmbtersedia().getSelectedIndex());
        
        KamarDAO dao = new KamarDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, kamar);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void update(){
         kamar = new Kamar();
        
        kamar.setNokamar(view.getTxtnokamar().getText());
        String t_idjenis[]=view.getCmbjenis().getSelectedItem().toString().split("-");
        kamar.setIdjenis(t_idjenis[0]);
        kamar.setStatus(view.getCmbtersedia().getSelectedIndex());
        
        KamarDAO dao = new KamarDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, kamar);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }  
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtnokamar().getText().toString();
            KamarDAO dao = new KamarDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cariData(){
        String idCari = view.getTxtnokamar().getText().toString();
        if (idCari.length()>0){
            try {
                KamarDAO dao = new KamarDAO();
                Koneksi k = new Koneksi();
                Connection conn = k.getKoneksi();
                kamar = dao.getKamar(conn, idCari);
                if(kamar !=null){
                    
                    
                    
                    JenisKamarDAO pdao = new JenisKamarDAO();
                    JenisKamar jeniskamar = pdao.getJenisKamar(conn, kamar.getIdjenis());
                    view.getCmbjenis().setSelectedItem(jeniskamar.getIdjeniskamar()+"-"+jeniskamar.getNamajeniskamar());
                    view.getTxtnokamar().setText(kamar.getNokamar());
                    JOptionPane.showMessageDialog(view, "Data ditemukan !");
                }
                else{
                    JOptionPane.showMessageDialog(view, "Data tidak ada");
                }
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else{
            
                JOptionPane.showMessageDialog(view, "Masukkan ID");
            }
   }
    public void isiComboKamar(){
        try {
            JenisKamarDAO dao = new JenisKamarDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<JenisKamar> listJeniskamar = dao.getAllJenisKamar(c);
            view.getCmbjenis().removeAllItems();
            for (JenisKamar jeniskamar : listJeniskamar){
                view.getCmbjenis().addItem(jeniskamar.getIdjeniskamar()+"-"+jeniskamar.getNamajeniskamar());
            }
        } catch (SQLException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void bersihFormJenis(){
        view.getCmbjenis().setSelectedItem("");
        view.getTxtnokamar().setText("");   
        
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTableKamar().getModel();
            tabelModel.setRowCount(0);
            KamarDAO dao = new KamarDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Kamar> listkamar = dao.getAllkamar(c);
            for(Kamar j: listkamar){
                Object data[]={
                  j.getIdjenis(),j.getNokamar(),j.getStatus()
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void Status(){
        view.getCmbtersedia().removeAllItems();
        view.getCmbtersedia().addItem("0-Ada");
        view.getCmbtersedia().addItem("1-Terpakai");
    }
 
    
}
