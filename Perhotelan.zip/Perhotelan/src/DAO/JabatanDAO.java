/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Jabatan;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class JabatanDAO {
    public void insert(Connection con, Jabatan jabatan) throws SQLException{
        String sql = "insert into jabatan values(?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, jabatan.getNamajabatam());
        ps.setString(2, jabatan.getIdjabatan());

        
        
        ps.executeUpdate();
    }
    
    public void update(Connection con,  Jabatan jabatan) throws SQLException{
        String sql = "update jabatan set id_jabatan=? where nama_jabatan=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(2, jabatan.getNamajabatam());
        ps.setString(1, jabatan.getIdjabatan());
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from jabatan where id_jabatan=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Jabatan getJabatan(Connection con, String id) throws SQLException{
        String sql = "select * from jabatan where nama_jabatan=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Jabatan jabatan = null;
        if(rs.next()){
            jabatan = new Jabatan();
            jabatan.setNamajabatam(rs.getString(1));
            jabatan.setIdjabatan(rs.getString(2));
            

        }
        return jabatan;
    }
    
   
    public List<Jabatan> getAllJabatan(Connection con) throws SQLException{
        String sql = "select * from jabatan";
        PreparedStatement ps = con.prepareStatement(sql);
        Jabatan jabatan = null;
        List<Jabatan> listJabatan= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            jabatan = new Jabatan();
            jabatan.setNamajabatam(rs.getString(1));
            jabatan.setIdjabatan(rs.getString(2));
            listJabatan.add(jabatan);
        }
        return listJabatan;
    }

    
}
