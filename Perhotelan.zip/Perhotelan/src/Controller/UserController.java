/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.UserDAO;
import Koneksi.Koneksi;
import Model.User;
import View.FormUser;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Elang AbdUl Azis
 */
public class UserController {
    FormUser view;
    User user;
    UserDAO userDAO;
    Connection con;
    Koneksi k;
    
    public UserController(FormUser view) {
        try {
            this.view = view;
            user = new User();
            userDAO = new UserDAO();
            k = new Koneksi();
            con = k.getKoneksi();
        } catch (SQLException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void insertJenis(){
        user = new User();
        user.setUsername(view.getTxtusername().getText());
        user.setPassword(view.getTxtpassword().getText());
        String temp[]=view.getCmbjabatan().getSelectedItem().toString().split("-");
        user.setJabatan(Integer.parseInt(temp[0]));
        UserDAO dao = new UserDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, user);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view,"Error "+ex.getMessage());
        }    
        
    }
     public void bersihFormUser(){
        view.getTxtusername().setText("");
        view.getTxtpassword().setText(""); 
    }
    
    public void isiComboJenis(){
        view.getCmbjabatan().removeAllItems();
        view.getCmbjabatan().addItem("1-Admin");
        view.getCmbjabatan().addItem("2-Operator");
        
    }
}
