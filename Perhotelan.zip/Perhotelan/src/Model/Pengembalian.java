/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Elang AbdUl Azis
 */
public class Pengembalian {
    String idcus,checkout,idkamar,nomorkamar,jeniskamar;

    public String getIdcus() {
        return idcus;
    }

    public void setIdcus(String idcus) {
        this.idcus = idcus;
    }

    public String getCheckout() {
        return checkout;
    }

    public void setCheckout(String checkout) {
        this.checkout = checkout;
    }

    public String getIdkamar() {
        return idkamar;
    }

    public void setIdkamar(String idkamar) {
        this.idkamar = idkamar;
    }

    public String getNomorkamar() {
        return nomorkamar;
    }

    public void setNomorkamar(String nomorkamar) {
        this.nomorkamar = nomorkamar;
    }

    public String getJeniskamar() {
        return jeniskamar;
    }

    public void setJeniskamar(String jeniskamar) {
        this.jeniskamar = jeniskamar;
    }
    
}
