/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Pemakaian;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LABSIKOMP22
 */
public class PemakaianDAO {
  public void insert(Connection con, Pemakaian pemakaian) throws SQLException{
        String sql = "insert into pemakaian values(?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, pemakaian.getIdjenis());
        ps.setString(2, pemakaian.getIdcustomer());

        
        
        ps.executeUpdate();
    }
    
    public void update(Connection con,  Pemakaian pemakaian ) throws SQLException{
        String sql = "update pemakaian set id_customer=? where id_jenis=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, pemakaian.getIdjenis());
        ps.setString(2, pemakaian.getIdcustomer());
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from pemakaian where id_jenis=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Pemakaian getPemakaian(Connection con, String id) throws SQLException{
        String sql = "select * from pemakaian where id_jenis=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Pemakaian pemakaian = null;
        if(rs.next()){
            pemakaian = new Pemakaian();
            pemakaian.setIdjenis(rs.getString(1));
            pemakaian.setIdcustomer(rs.getString(2));
            

        }
        return pemakaian;
    }
    
   
    public List<Pemakaian> getAllpemakaian(Connection con) throws SQLException{
        String sql = "select * from pemakaian";
        PreparedStatement ps = con.prepareStatement(sql);
        Pemakaian pemakaian = null;
        List<Pemakaian> listpemakaian= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            pemakaian = new Pemakaian();
            pemakaian.setIdjenis(rs.getString(1));
            pemakaian.setIdcustomer(rs.getString(2));
            listpemakaian.add(pemakaian);
        }
        return listpemakaian;
    }
    
}
