/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class CustomerDAO {
    public void insert(Connection con, Customer customer) throws SQLException{
        String sql = "insert into customer values(?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, customer.getIdcus());
        ps.setString(2, customer.getNamacus());
        ps.setString(3, customer.getNopcus());
        
        ps.executeUpdate();
    }
    
    public void update(Connection con,  Customer customer) throws SQLException{
        String sql = "update customer set nama_customer=?, no_telp_customer=? where id_customer=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, customer.getNamacus());
        ps.setString(2, customer.getNopcus());
        ps.setString(3, customer.getIdcus());
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from customer where id_customer=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Customer getCustomer(Connection con, String id) throws SQLException{
        String sql = "select * from customer where id_customer=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Customer customer = null;
        if(rs.next()){
            customer = new Customer();
            customer.setIdcus(rs.getString(1));
            customer.setNamacus(rs.getString(2));
            customer.setNopcus(rs.getString(3));

        }
        return customer;
    }
    
   
    public List<Customer> getAllCustomer(Connection con) throws SQLException{
        String sql = "select * from customer";
        PreparedStatement ps = con.prepareStatement(sql);
        Customer customer = null;
        List<Customer> listCustomer= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            customer = new Customer();
            customer.setIdcus(rs.getString(1));
            customer.setNamacus(rs.getString(2));
            customer.setNopcus(rs.getString(3));
            listCustomer.add(customer);
        }
        return listCustomer;
    }
     public ResultSet getResultset(Connection con, String query) throws SQLException{
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }

}
