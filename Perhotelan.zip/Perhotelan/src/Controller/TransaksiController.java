/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.FasilitasDAO;
import DAO.JenisKamarDAO;
import DAO.KamarDAO;
import DAO.TransaksiDAO;
import Koneksi.Koneksi;
import Model.JenisKamar;
import Model.Kamar;
import Model.Transaksi;
import View.DialogTransaksi;

import View.FormTrasnsaksi;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
public class TransaksiController {
       FormTrasnsaksi view;
      DialogTransaksi dialogTransaksi;
    Transaksi transaksi;
    TransaksiDAO transaksiDAO;
    JenisKamarDAO jenisKamarDAO;
    FasilitasDAO fasilitasDAO;
    KamarDAO kamarDAO;
    Kamar kamar;
    Connection c;
    int hari;
    Koneksi k;
    JenisKamar jenisKamar;
    int harga_kamar=0;
    int harga_fasilitas;
    int total;
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public TransaksiController(TransaksiDAO transaksiDAO, Connection c) {
        this.transaksiDAO = transaksiDAO;
        k = new Koneksi();
           try {
               c = k.getKoneksi();
           } catch (SQLException ex) {
               Logger.getLogger(TransaksiController.class.getName()).log(Level.SEVERE, null, ex);
           } catch (ClassNotFoundException ex) {
               Logger.getLogger(TransaksiController.class.getName()).log(Level.SEVERE, null, ex);
           }
        
    
    }
  
  

     
    
    
    public TransaksiController(FormTrasnsaksi view) {
        this.view = view;
        transaksi =new Transaksi();
        jenisKamarDAO = new JenisKamarDAO();
        transaksiDAO = new TransaksiDAO();
        k = new Koneksi();
       jenisKamar = new JenisKamar();
       kamar = new Kamar();
       kamarDAO = new  KamarDAO();
        try {
            c = k.getKoneksi();
        } catch (SQLException ex) {
            Logger.getLogger(TransaksiController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TransaksiController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       transaksi= new Transaksi();
    }
       
     
     

   
  
    public void proses() {
        String tglSekarang = view.getDcocheckin().getText();
        String tglKembali = view.getDcocheckout().getText();
        
        int harga=Integer.parseInt(view.getTxthargakamar().getText());
        try {
            hari = transaksiDAO.getTerlambat(tglKembali,tglSekarang, c);
            harga_kamar=harga*hari;
            view.getTvTot().setText(harga_kamar + "");
            
        } catch (SQLException ex) {
            Logger.getLogger(TransaksiController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void proses1(){
        double fasilitas=Double.parseDouble(view.getTxthargafasi().getText());
        double total;
        total=fasilitas+harga_kamar;
        view.getTxttotal().setText(total+"");
    }

  
    public void insertTransaksi(){
           try {
               transaksi = new Transaksi();
               transaksi.setTgl(view.getDcotanggal().getText());
               transaksi.setIdkar(view.getTxtidkar().getText());
               transaksi.setIdcus(view.getTxtidcus().getText());
               transaksi.setIdkamar(view.getTxtidkamar().getText());
               transaksi.setNomorkamar(view.getTxtnomorkamar().getText());
               transaksi.setIdfasi(view.getTxtidfasilitas().getText());
               transaksi.setCheckin(view.getDcocheckin().getText());
               transaksi.setCheckout(view.getDcocheckout().getText());
               transaksi.setHargakamar(Integer.parseInt(view.getTxthargakamar().getText()));
               transaksi.setTvtot(Integer.parseInt(view.getTvTot().getText()));
               transaksi.setHargafasi(Integer.parseInt(view.getTxthargafasi().getText()));
               transaksi.setTotal((int) Double.parseDouble(view.getTxttotal().getText()));
               TransaksiDAO dao = new TransaksiDAO(); //DAO
               Koneksi k = new Koneksi(); //koneksi
               kamarDAO.updateStatus(c, 1, view.getTxtnomorkamar().getText());
               
               
               try {
               Connection c = k.getKoneksi();
               } catch (ClassNotFoundException ex) {
                   JOptionPane.showMessageDialog(view, ex.getMessage());
               }
               
               if (kamar.getStatus()== 0){
                   transaksiDAO.insert(c, transaksi);
                   JOptionPane.showMessageDialog(view, "Entri Data Ok");
                   bersihFormJenis();
                   tampilTabel();
               }else{
                   JOptionPane.showMessageDialog(view, "Silahkan Menempati");
               }
           } catch (SQLException ex) {
               JOptionPane.showMessageDialog(view, ex.getMessage());
           }
           
                  
    }
    
    public void update(){
        transaksi = new Transaksi();
         transaksi.setTgl(view.getDcotanggal().getText());
        transaksi.setIdkar(view.getTxtidkar().getText());
        transaksi.setIdcus(view.getTxtidcus().getText()); 
        transaksi.setIdkamar(view.getTxtidkamar().getText());
        transaksi.setIdfasi(view.getTxtidfasilitas().getText());
        transaksi.setCheckin(view.getDcocheckin().getText());
        transaksi.setCheckout(view.getDcocheckout().getText());
        transaksi.setHargakamar(Integer.parseInt(view.getTxthargakamar().getText()));
        transaksi.setTvtot(Integer.parseInt(view.getTvTot().getText()));
        transaksi.setHargafasi(Integer.parseInt(view.getTxthargafasi().getText()));
        transaksi.setTotal((int) Double.parseDouble(view.getTxttotal().getText()));
        
        
        TransaksiDAO dao = new TransaksiDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, transaksi);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        } 
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtidcus().getText().toString();
            TransaksiDAO dao = new TransaksiDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

          
    
    public void cariData(){
        String idCari = view.getTxtidcus().getText();
        if(idCari.length()>0){
            try {
                TransaksiDAO dao = new TransaksiDAO();
                Koneksi k = new Koneksi();
                Connection c = k.getKoneksi();
                transaksi = dao.getTransaksi(c, idCari);
                if(transaksi!=null){
                    view.getDcotanggal().setText(transaksi.getTgl());
                    view.getTxtidkar().setText(transaksi.getIdkar());
                     view.getTxtidcus().setText(transaksi.getIdcus());
                    view.getTxtidkamar().setText(transaksi.getIdkamar());
                     view.getTxtidfasilitas().setText(transaksi.getIdfasi());
                    view.getDcocheckin().setText(transaksi.getCheckin());
                     view.getDcocheckout().setText(transaksi.getCheckout());
                    view.getTxthargakamar().setText(transaksi.getHargakamar()+"");
                     view.getTxthargafasi().setText(transaksi.getHargafasi()+"");
                    view.getTxttotal().setText(transaksi.getTotal()+"");
                    view.getTvTot().setText(transaksi.getTvtot()+"");
                    
                } else{
                    JOptionPane.showMessageDialog(view, "Data Tidak Ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(view, "Input ID Cari");
        }
    }
     public void cariData1(){
        String idCari = view.getTxtidcus().getText();
        if(idCari.length()>0){
            try {
                TransaksiDAO dao = new TransaksiDAO();
                Koneksi k = new Koneksi();
                Connection c = k.getKoneksi();
                transaksi = dao.getTransaksi(c, idCari);
                if(transaksi!=null){
                    view.getDcotanggal().setText(transaksi.getTgl());
                    
                    
                } else{
                    JOptionPane.showMessageDialog(view, "Data Tidak Ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(view, "Input ID Cari");
        }
    }
    
    public void bersihFormJenis(){
                     view.getDcotanggal().setText("");
                    view.getTxtidkar().setText("");
                    view.getTxtnamakar().setText("");
                     view.getTxtidcus().setText("");
                    view.getTxtnamacus().setText("");
                    view.getTxtidkamar().setText("");
                    view.getTxtnomorkamar().setText("");
                    view.getTxtjeniskamar().setText("");
                     view.getTxtidfasilitas().setText("");
                     view.getTxtnofasi().setText("");
                    view.getDcocheckin().setText("");
                     view.getDcocheckout().setText("");
                    view.getTxthargakamar().setText("");
                     view.getTxthargafasi().setText("");
                    view.getTxttotal().setText("");
                    view.getTvTot().setText("");
                    
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTableTransaksi().getModel();
            tabelModel.setRowCount(0);
            TransaksiDAO dao = new TransaksiDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Transaksi> listTransaksi = dao.getAllTransaksi(c);
            for(Transaksi j: listTransaksi){
                Object data[]={
                  j.getTgl(),j.getIdkar(),j.getIdcus()
                        ,j.getIdkamar(),j.getIdfasi()
                        ,j.getCheckin(),j.getCheckout(),j.getHargakamar()
                        ,j.getTvtot(),j.getHargafasi(),j.getTotal()
                    
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    
    
}
