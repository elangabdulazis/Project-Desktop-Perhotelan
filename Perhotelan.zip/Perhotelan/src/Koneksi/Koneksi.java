/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Elang AbdUl Azis
 */
public class Koneksi {

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private String driver="com.mysql.jdbc.Driver";
    private String url="jdbc:mysql://localhost/db_perhotelan";
    private String username="root";
    private String password="";
    
    public Connection getKoneksi() throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.jdbc.Driver");//(--->>>>JIKA BERMASALAH<<<<-----)
        return DriverManager.getConnection(url, username, password);
    }
  
   
    
}
