/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.JabatanDAO;
import Koneksi.Koneksi;
import Model.Jabatan;
import View.FormJabatan;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
public class JabatanController {
     FormJabatan view;
     Jabatan jabatan;
    
    public JabatanController(FormJabatan view) {
        this.view = view;
        
       jabatan= new Jabatan();
    }

  
    public void insertJabatan(){
        jabatan = new Jabatan();
        jabatan.setIdjabatan(view.getTxtidja().getText());
        jabatan.setNamajabatam(view.getTxtnamaja().getText());
        
        JabatanDAO dao = new JabatanDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, jabatan);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void update(){
        jabatan = new Jabatan();
        jabatan.setNamajabatam(view.getTxtnamaja().getText());
        jabatan.setIdjabatan(view.getTxtidja().getText());
        
        JabatanDAO dao = new JabatanDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, jabatan);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }        
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtidja().getText();
            JabatanDAO dao = new JabatanDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException ex) {
            Logger.getLogger(JabatanController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JabatanController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cariData(){
        String idCari = view.getTxtnamaja().getText();
        if(idCari.length()>0){
            try {
                JabatanDAO dao = new JabatanDAO();
                Koneksi k = new Koneksi();
                Connection c = k.getKoneksi();
                jabatan = dao.getJabatan(c, idCari);
                if(jabatan!=null){
                    view.getTxtnamaja().setText(jabatan.getNamajabatam());
                    view.getTxtidja().setText(jabatan.getIdjabatan());
                } else{
                    JOptionPane.showMessageDialog(view, "Data Tidak Ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(view, "Input ID Cari");
        }
    }
    
    public void bersihFormJenis(){
        view.getTxtnamaja().setText("");
        view.getTxtidja().setText("");   
        
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTable().getModel();
            tabelModel.setRowCount(0);
            JabatanDAO dao = new JabatanDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Jabatan> listjabatan = dao.getAllJabatan(c);
            for(Jabatan j: listjabatan){
                Object data[]={
                  j.getNamajabatam(),j.getIdjabatan()
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
