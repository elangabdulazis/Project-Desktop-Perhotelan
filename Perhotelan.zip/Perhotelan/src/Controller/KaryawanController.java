/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.JabatanDAO;
import DAO.KaryawanDAO;
import Koneksi.Koneksi;
import Model.Jabatan;
import Model.Karyawan;
import View.DialogKaryawan;
import View.FormKaryawan;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Elang AbdUl Azis
 */
public class KaryawanController {
    FormKaryawan view;
    Karyawan karyawan;
    DialogKaryawan dialogKaryawan;
    
    public KaryawanController(FormKaryawan view) {
        this.view = view;
    }
    public  KaryawanController(DialogKaryawan dialogKaryawan){
    this.dialogKaryawan = dialogKaryawan;
        
        
        
       karyawan= new Karyawan();
    }
    public void ViewDialogKaryawan(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) dialogKaryawan.getTabeldialogkaryawan().getModel();
            tabelModel.setRowCount(0);
            KaryawanDAO dao = new KaryawanDAO(); //DAO
            Koneksi k = new Koneksi(); //koneksi
            String cari = dialogKaryawan.getTxtFilterb().getText();
            Connection c = k.getKoneksi();
            String sql = "select id_karyawan,nama_karyawan from karyawan where id_karyawan like '" + cari + "%' or nama_karyawan like '" + cari + "%'";
            ResultSet rs = dao.getResultset(c, sql);
            while (rs.next()) {
                Object data[] = {
                    rs.getString(1),rs.getString(2)
                };
                tabelModel.addRow(data);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JenisKamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }

  
    public void insertKaryawan(){
        karyawan = new Karyawan();
        karyawan.setIdkaryawan(view.getTxtidkar().getText());
        karyawan.setNama(view.getTxtnama().getText());
        karyawan.setAlamat(view.getTxtalamat().getText());
        karyawan.setNotelp(view.getTxtnotelp().getText());
        String t_jenis[]=view.getCmbidjenis().getSelectedItem().toString().split("-");
        karyawan.setIdjenis(t_jenis[0]);
        KaryawanDAO dao = new KaryawanDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.insert(c, karyawan);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage());
        }          
    }
    
    public void update(){
        karyawan = new Karyawan();
        karyawan.setIdkaryawan(view.getTxtidkar().getText());
        karyawan.setNama(view.getTxtnama().getText());
        karyawan.setAlamat(view.getTxtalamat().getText());
        karyawan.setNotelp(view.getTxtnotelp().getText());
         String t_jenis[]=view.getCmbidjenis().getSelectedItem().toString().split("-");
        karyawan.setIdjenis(t_jenis[0]);
        KaryawanDAO dao = new KaryawanDAO(); //DAO
        Koneksi k = new Koneksi(); //koneksi
        try {
            Connection c = k.getKoneksi();
            dao.update(c, karyawan);
            JOptionPane.showMessageDialog(view, "Entri Data OK");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, ex);
        }          
    }
    
    public void delete(){
        try {
            String idDelete = view.getTxtidkar().getText();
            KaryawanDAO dao = new KaryawanDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            dao.delete(c, idDelete);
            JOptionPane.showMessageDialog(view, "Delete Data OK");
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cariData(){
        String idCari = view.getTxtidkar().getText();
        if(idCari.length()>0){
            try {
                KaryawanDAO dao = new KaryawanDAO();
                Koneksi k = new Koneksi();
                Connection c = k.getKoneksi();
                karyawan = dao.getKaryawan(c, idCari);
                if(karyawan!=null){
                    view.getTxtidkar().setText(karyawan.getIdkaryawan());
                    view.getTxtnama().setText(karyawan.getNama());
                    view.getTxtalamat().setText(karyawan.getAlamat());
                    view.getTxtnotelp().setText(karyawan.getNotelp());
                    view.getCmbidjenis().setSelectedItem(karyawan.getIdjenis()+"-");
                } else{
                    JOptionPane.showMessageDialog(view, "Data Tidak Ada");
                }
            } catch (SQLException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else {
            JOptionPane.showMessageDialog(view, "Input ID Cari");
        }
    }
    
    public void bersihFormJenis(){
        view.getTxtidkar().setText("");
        view.getTxtnama().setText("");  
        view.getTxtalamat().setText("");
        view.getTxtnotelp().setText("");
        
        
        
    } public void isiCombojabatan(){
        try {
            JabatanDAO dao = new JabatanDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Jabatan> listJenisJab = dao.getAllJabatan(c);
            view.getCmbidjenis().removeAllItems();
            for (Jabatan jenisJabatan : listJenisJab){
                 view.getCmbidjenis().addItem(jenisJabatan.getIdjabatan()+"-"+jenisJabatan.getNamajabatam());
            }
        } catch (SQLException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KamarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void tampilTabel(){
        try {
            DefaultTableModel tabelModel = (DefaultTableModel) view.getTabel().getModel();
            tabelModel.setRowCount(0);
            KaryawanDAO dao = new KaryawanDAO();
            Koneksi k = new Koneksi();
            Connection c = k.getKoneksi();
            List<Karyawan> listKaryawan = dao.getAllKaryawan(c);
            for(Karyawan j: listKaryawan){
                Object data[]={
                  j.getIdkaryawan(),j.getNama(),j.getAlamat(),j.getNotelp(),j.getIdjenis(),
                };
                tabelModel.addRow(data);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
}
