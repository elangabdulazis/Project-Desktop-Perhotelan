/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Elang AbdUl Azis
 */
public class Transaksi {
    private String tgl;
    private String idkar,namakar;
    private String idcus,namacus;
    private String idkamar,jeniskamar,nomorkamar;
    private String idfasi,nofasi;
    private String checkin,checkout;
    private int hargakamar,hargafasi,tvtot;
    
     private double total;

    public int getTvtot() {
        return tvtot;
    }

    public void setTvtot(int tvtot) {
        this.tvtot = tvtot;
    }

    public String getTgl() {
        return tgl;
    }

    public void setTgl(String tgl) {
        this.tgl = tgl;
    }

    public String getIdkar() {
        return idkar;
    }

    public void setIdkar(String idkar) {
        this.idkar = idkar;
    }

    public String getNamakar() {
        return namakar;
    }

    public void setNamakar(String namakar) {
        this.namakar = namakar;
    }

    public String getIdcus() {
        return idcus;
    }

    public void setIdcus(String idcus) {
        this.idcus = idcus;
    }

    public String getNamacus() {
        return namacus;
    }

    public void setNamacus(String namacus) {
        this.namacus = namacus;
    }

    public String getIdkamar() {
        return idkamar;
    }

    public void setIdkamar(String idkamar) {
        this.idkamar = idkamar;
    }

    public String getJeniskamar() {
        return jeniskamar;
    }

    public void setJeniskamar(String jeniskamar) {
        this.jeniskamar = jeniskamar;
    }

    public String getNomorkamar() {
        return nomorkamar;
    }

    public void setNomorkamar(String nomorkamar) {
        this.nomorkamar = nomorkamar;
    }

    public String getIdfasi() {
        return idfasi;
    }

    public void setIdfasi(String idfasi) {
        this.idfasi = idfasi;
    }

    public String getNofasi() {
        return nofasi;
    }

    public void setNofasi(String nofasi) {
        this.nofasi = nofasi;
    }

    public String getCheckin() {
        return checkin;
    }

    public void setCheckin(String checkin) {
        this.checkin = checkin;
    }

    public String getCheckout() {
        return checkout;
    }

    public void setCheckout(String checkout) {
        this.checkout = checkout;
    }

    public int getHargakamar() {
        return hargakamar;
    }

    public void setHargakamar(int hargakamar) {
        this.hargakamar = hargakamar;
    }

    public int getHargafasi() {
        return hargafasi;
    }

    public void setHargafasi(int hargafasi) {
        this.hargafasi = hargafasi;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

 
    
}
