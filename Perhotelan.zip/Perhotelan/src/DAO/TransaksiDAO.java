/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Transaksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Elang AbdUl Azis
 */
public class TransaksiDAO {
    
    public void insert(Connection con, Transaksi transaksi) throws SQLException{
        String sql = "insert into Transaksi values(?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, transaksi.getTgl());
        ps.setString(2, transaksi.getIdkar());
        ps.setString(3, transaksi.getIdcus());
        ps.setString(4, transaksi.getNomorkamar());
        ps.setString(5, transaksi.getIdfasi());
        ps.setString(6, transaksi.getCheckin());
        ps.setString(7, transaksi.getCheckout());
        ps.setInt(8, transaksi.getHargakamar());
        ps.setInt(9, transaksi.getTvtot());
        ps.setInt(10, transaksi.getHargafasi());
        ps.setDouble(11, transaksi.getTotal());
        
        ps.executeUpdate();
    }
    
    public void update(Connection con, Transaksi transaksi) throws SQLException{
        String sql = "update transaksi set id_karyawan=?, id_customer=? , id_kamar=?"
                + " , id_fasilitas=?, check_in=? , check_out=? , harga_kamar=? , total_hari=? , harga_fasilitas=? , total_pembayaran=? where tanggal=?";
        PreparedStatement ps = con.prepareStatement(sql);
       
           
        ps.setString(1, transaksi.getTgl());
        ps.setString(2, transaksi.getIdkar());
        ps.setString(3, transaksi.getIdcus());
        ps.setString(4, transaksi.getIdkamar());
        ps.setString(5, transaksi.getIdfasi());
        ps.setString(6, transaksi.getCheckin());
        ps.setString(7, transaksi.getCheckout());
        ps.setInt(8, transaksi.getHargakamar());
        ps.setInt(9, transaksi.getTvtot());
        ps.setInt(10, transaksi.getHargafasi());
        ps.setDouble(11, transaksi.getTotal());
        
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from transaksi where id_customer=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Transaksi getTransaksi(Connection con, String id) throws SQLException{
        String sql = "select * from transaksi where id_customer=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Transaksi transaksi = null;
        if(rs.next()){
            transaksi = new Transaksi();
            transaksi.setTgl(rs.getString(1));
            transaksi.setIdkar(rs.getString(2));
            transaksi.setIdcus(rs.getString(3));
            transaksi.setIdkamar(rs.getString(4));
            transaksi.setIdfasi(rs.getString(5));
            transaksi.setCheckin(rs.getString(6));
            transaksi.setCheckout(rs.getString(7));
            transaksi.setHargakamar(rs.getInt(8));
            transaksi.setTvtot(rs.getInt(9));
            transaksi.setHargafasi(rs.getInt(10));
            transaksi.setTotal(rs.getDouble(11));

        }
        return transaksi;
    }
    
   
    public List<Transaksi> getAllTransaksi(Connection con) throws SQLException{
        String sql = "select * from transaksi";
        PreparedStatement ps = con.prepareStatement(sql);
        Transaksi transaksi = null;
        List<Transaksi> listTransaksi= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
           transaksi = new Transaksi();
            transaksi.setTgl(rs.getString(1));
            transaksi.setIdkar(rs.getString(2));
            transaksi.setIdcus(rs.getString(3));
            transaksi.setIdkamar(rs.getString(4));
            transaksi.setIdfasi(rs.getString(5));
            transaksi.setCheckin(rs.getString(6));
            transaksi.setCheckout(rs.getString(7));
            transaksi.setHargakamar(rs.getInt(8));
            transaksi.setTvtot(rs.getInt(9));
            transaksi.setHargafasi(rs.getInt(10));
            transaksi.setTotal(rs.getInt(11));
            listTransaksi.add(transaksi);
        }
        return listTransaksi;
    }
    
    public int getTerlambat(String tgldiKembalikan, String tglKembali, Connection con) throws SQLException{
        String sql = "select datediff(?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, tgldiKembalikan);
        ps.setString(2, tglKembali);
        ResultSet rs = ps.executeQuery();
        int terlambat = 0;
        if(rs.next()){
            terlambat = rs.getInt(1);
        }
        return terlambat;
    }
    public ResultSet getResultset(Connection con, String query) throws SQLException{
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }
    
}

