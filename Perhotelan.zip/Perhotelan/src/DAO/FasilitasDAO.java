/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Fasilitas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LABSIKOMP22
 */
public class FasilitasDAO {
     public void insert(Connection con, Fasilitas fasilitas) throws SQLException{
        String sql = "insert into fasilitas values(?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, fasilitas.getNofasilitas());
        ps.setString(2, fasilitas.getIdjenis());

        
        
        ps.executeUpdate();
    }
    
    public void update(Connection con,  Fasilitas fasilitas) throws SQLException{
        String sql = "update fasilitas set no_fasilitas=? where  id_jenis=?  ";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, fasilitas.getNofasilitas());
        ps.setString(2, fasilitas.getIdjenis());
        ps.executeUpdate();
    }
    
    public void delete(Connection con, String id) throws SQLException{
        String sql = "delete from fasilitas where  no_fasilitas=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ps.executeUpdate();
    }
    
    public Fasilitas getFasilitas(Connection con, String id) throws SQLException{
        String sql = "select * from fasilitas where  no_fasilitas=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        Fasilitas fasilitas = null;
        if(rs.next()){
            fasilitas = new Fasilitas();
            fasilitas.setNofasilitas(rs.getString(1));
            fasilitas.setIdjenis(rs.getString(2));
            
        }
        return fasilitas;
    }
    
   
    public List<Fasilitas> getAllfasilitas(Connection con) throws SQLException{
        String sql = "select * from fasilitas";
        PreparedStatement ps = con.prepareStatement(sql);
        Fasilitas fasilitas = null;
        List<Fasilitas> listFasilitas= new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()){
            fasilitas = new Fasilitas();
            fasilitas.setIdjenis(rs.getString(2));
            fasilitas.setNofasilitas(rs.getString(1));
            listFasilitas.add(fasilitas);
        }
        return listFasilitas;
    }
    public ResultSet getResultset(Connection con, String query) throws SQLException{
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        return rs;
    }

}
